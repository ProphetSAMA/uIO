package fun.wsss.uio.model;

public class RoomConfig {
    private int buildingId;
    private int floorId;
    private int roomId;

    public RoomConfig(int buildingId, int floorId, int roomId) {
        this.buildingId = buildingId;
        this.floorId = floorId;
        this.roomId = roomId;
    }

    // Getters and Setters
    public int getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(int buildingId) {
        this.buildingId = buildingId;
    }

    public int getFloorId() {
        return floorId;
    }

    public void setFloorId(int floorId) {
        this.floorId = floorId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
} 