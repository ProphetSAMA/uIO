package fun.wsss.uio.utils;

import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 发送HTTP请求的工具类
 *
 * @author Wsssfun
 */
@Slf4j
@Component
public class Http {
    private final RestTemplate restTemplate = new RestTemplate();
    
    @Value("${power.api.url:https://cloudpaygateway.59wanmei.com:8087/paygateway/smallpaygateway/trade}")
    private String apiUrl;
    
    @Value("${power.api.payproid:953}")
    private int payproId;
    
    @Value("${power.api.schoolcode:1402}")
    private String schoolCode;

    /**
     * 根据区域号查询电量
     * @param areaCode 区域号，格式如 "1-1" 或 "2-1"
     * @param floor 楼层
     * @param roomNumber 房间号
     */
    public String sendPostRequest(String areaCode, int floor, int roomNumber) {
        String[] areaParts = areaCode.split("-");
        return sendPostRequest(
            Integer.parseInt(areaParts[0]), 
            Integer.parseInt(areaParts[1]), 
            floor, 
            roomNumber
        );
    }

    /**
     * 原有的查询方法
     */
    public String sendPostRequest(int mainArea, int subArea, int floor, int roomNumber) {
        try {
            String roomVerify = String.format("%d-%d--%d-%d", mainArea, subArea, floor, roomNumber);
            log.info("开始查询房间[{}]电量", roomVerify);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // 构建请求体，严格按照指定格式
            String bizContent = String.format(
                "{\"payproid\":%d,\"schoolcode\":\"%s\",\"roomverify\":\"%s\",\"businesstype\":2}",
                payproId, schoolCode, roomVerify
            );

            JSONObject requestBody = new JSONObject();
            requestBody.put("method", "samllProgramGetRoomState");
            requestBody.put("bizcontent", bizContent);

            log.info("请求参数: {}", requestBody.toJSONString());

            HttpEntity<String> request = new HttpEntity<>(requestBody.toJSONString(), headers);
            ResponseEntity<String> responseEntity = restTemplate.exchange(
                apiUrl,
                HttpMethod.POST,
                request,
                String.class
            );

            String response = responseEntity.getBody();
            log.info("响应数据: {}", response);
            
            return response;
        } catch (Exception e) {
            log.error("房间[{}-{}-{}-{}]电量查询异常: {}", 
                mainArea, subArea, floor, roomNumber, e.getMessage(), e);
            throw e;
        }
    }
}
